# -*- coding: utf-8 -*-
"""Problem Sheet 2.

Gradient Descent
"""
import numpy as np
import costs


def compute_gradient(y, tx, w):
    """Compute the gradient."""
    # ***************************************************
    # INSERT YOUR CODE HERE
    # TODO: compute gradient and loss
    [a,b]=w.shape
    if a<b:
        w=w.T
    N=np.shape(tx)[0]
    #print(w)
    e=y-tx.dot(w)
    #print(e.shape)
    grad=-1/N*tx.T.dot(e)
    return grad
    
    # ***************************************************
    raise NotImplementedError

def gradient_descent(y, tx, initial_w, max_iters, gamma): 
    """Gradient descent algorithm."""
    # Define parameters to store w and loss
    ws = [initial_w]
    losses = []
    N=len(y)
    y=np.reshape(y,(n,1))
    w = np.reshape(initial_w,(2,1))
  
    for n_iter in range(max_iters):
        # ***************************************************
        # INSERT YOUR CODE HERE
        # TODO: compute gradient and loss
        grad=compute_gradient(y,tx,w)
        loss=compute_loss(y, tx, w)
        # ***************************************************
        #raise NotImplementedError
        # ***************************************************
        # INSERT YOUR CODE HERE
        # TODO: update w by gradient
    # print(w.shape)
    #    print(grad.shape)
        w=w-gamma*grad
        
        # ***************************************************
        #raise NotImplementedError
        # store w and loss
        ws.append(np.copy(w.flatten()))
        losses.append(loss)
        print("Gradient Descent({bi}/{ti}): loss={l}, w0={w0}, w1={w1}".format(
              bi=n_iter, ti=max_iters - 1, l=loss, w0=w[0], w1=w[1]))

    return losses, ws
