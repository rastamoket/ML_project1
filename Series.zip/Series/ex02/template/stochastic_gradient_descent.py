# -*- coding: utf-8 -*-
"""Problem Sheet 2.

Stochastic Gradient Descent
"""
import random

def compute_stoch_gradient(y, tx, w):
    """Compute a stochastic gradient for a specific point."""
    # ***************************************************
    # INSERT YOUR CODE HERE
    # TODO: implement stochastic gradient computation.
    e=(y-tx.T.dot(w))
    #batch_size=y.shape[0]
    
    grad=-tx*(e)
    return grad
   
    # ***************************************************
    raise NotImplementedError


def stochastic_gradient_descent(
        y, tx, initial_w, batch_size, max_epochs, gamma):          #max epoch = max iter
    """Stochastic gradient descent algorithm."""
    # ***************************************************
    # INSERT YOUR CODE HERE
    # TODO: implement stochastic gradient descent.
    ws = [initial_w]
 
    losses = []
    N=len(y)
    D=len(initial_w)
    y=np.reshape(y,(n,1))
    w = np.reshape(initial_w,(D,1))

    g=0
    for n_iter in range(max_epochs):
        w = np.reshape(w,(D,1))
        g=np.zeros((2,1))
     
        shuffle_indices = np.random.permutation(np.arange(N))
        y = y[shuffle_indices]
        tx = tx[shuffle_indices]
        for b_n in range(batch_size):
            n_rand=random.randint(1,N)
            y_n=y[n_rand]
            x_n=tx[n_rand]
            x_n=np.reshape(x_n,(D,1))
            g=g+1/batch_size * compute_stoch_gradient(y_n,x_n,w)         #x en vector (2,1) 
        
        #for minibatch_y, minibatch_tx in batch_iter(y, tx, batch_size):    
         #    g= compute_stoch_gradient(minibatch_y,minibatch_tx.T,w) 
      
        loss=compute_loss(y, tx, w)
        w=w-gamma*g
     
        ws.append(np.copy(w.flatten()))
        losses.append(loss)

        
    # ***************************************************
    #raise NotImplementedError
    return losses, ws