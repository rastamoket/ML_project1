# -*- coding: utf-8 -*-
"""a function used to compute the loss."""

import numpy as np

def compute_loss(y, tx, w, choice=True):
    """Calculate the loss.

    You can calculate the loss using mse or mae.
    """
    # ***************************************************
    # INSERT YOUR CODE HERE
    # TODO: compute loss by MSE / MAE
  
    N=np.shape(tx)[0]
    e=y-tx.dot(w)
    
    lossMSE=1/(2*N)* e.T.dot(e)
    lossMAE=1/N * sum(abs(e))
    
    if choice:
        return lossMSE
    else:
        return lossMAE
    # ***************************************************
    raise NotImplementedError
