# -*- coding: utf-8 -*-
"""Exercise 3.

Least Square
"""

import numpy as np


def least_squares(y, tx):
    """calculate the least squares."""
    # ***************************************************
    # INSERT YOUR CODE HERE
    # least squares: TODO
    # returns mse, and optimal weights
    # ***************************************************
    
    wopt=np.linalg.inv(tx.T.dot(tx)).dot(tx.T).dot(y)
    mse=compute_loss(y,tx,wopt)
    return mse,wopt
