# -*- coding: utf-8 -*-
"""Exercise 3.

Ridge Regression
"""

import numpy as np


def ridge_regression(y, tx, lamb):
    """implement ridge regression."""  
    # ***************************************************
    # INSERT YOUR CODE HERE
    # ridge regression: TODO
    # with no basis function
    [N,M]=tx.shape
    N=len(y)
    
    lambp=lamb/(2*N)
    wridge=np.linalg.inv(tx.T.dot(tx)+lambp*np.eye(M)).dot(tx.T).dot(y)
    return wridge
    
    # ***************************************************