# -*- coding: utf-8 -*-
"""Exercise 3.

Split the dataset based on the given ratio.
"""


import numpy as np



def split_data(x, y, ratio, seed=1):
    """split the dataset based on the split ratio."""
    # set seed
    np.random.seed(seed)
    N=len(y)
 
    Nt=int(np.floor(ratio*N));
    Ntindex=np.random.randint(0,N-1,Nt)
    
    Yt=y[Ntindex]
    Yv=np.delete(y,[Ntindex])
    
   
    Xt=x[Ntindex]
    Xv=np.delete(x,[Ntindex])
    
    St=Xt,Yt
    Sv=Xv,Yv
    # ***************************************************
    # INSERT YOUR CODE HERE
    # split the data based on the given ratio: TODO
    
    # ***************************************************
    return St, Sv
