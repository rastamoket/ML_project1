# -*- coding: utf-8 -*-
"""Functions for data preprocessing.
	1) The first replace the '-999' with the mean values of the other good point (divided in a group for the signal and the background).
    2) The second is the good one and it replaces the '-999' with the average of the others and then standardize every data (I checked and it works)."""

import numpy as np



def standard(matr):
    
    [N,D] = matr.shape 
    for i in range(D):
        col = matr[:,i]
        mean = np.mean(col)
        std = np.std(col)
        for j in range(N):
            col[j] = (col[j]-mean)/std
        matr[:,i] = col
    return matr


def bad_to_mean_val(tX):

    N,D = tX.shape
    counter = []
    for i in range(D):
        temp = 0
        for j in range(N):
            if tX[j][i] == -999:
                tX[j][i] = 0
                temp += 1
        counter.append((temp/N)*100)

    for p in range(len(counter)):
        if counter[p] != 0:
            col = tX[:,p]
            sig = []
            back = []
            for i in range(N):
                if col[i] != -999:
                    if y[i] == 1:
                        sig.append(col[i])
                    else:
                        back.append(col[i])
            
            mean_sig = np.mean(sig)
            mean_back = np.mean(back)

            for i in range(N):
                if col[i] == -999:
                    if y[i] == 1:
                        col[i] = mean_sig
                    else:
                        col[i] = mean_back
            tX[:,p] = col
    return tX



def data_fix_and_standardize(tX):

    N,D = tX.shape
    counter = []
    for i in range(D):
        temp = 0
        for j in range(N):
            if tX[j][i] == -999:
                temp += 1
        counter.append((temp/N)*100)
    for p in range(len(counter)):
        if counter[p] != 0:
            col = tX[:,p]
            good = []
            for i in range(N):
                if col[i] != -999:
                    good.append(col[i])
            
            mean_good = np.mean(good)
            
            for i in range(N):
                if col[i] == -999:
                    col[i] = mean_good
                  
            mean_good = np.mean(col)
            std_good = np.std(col)
            
            for i in range(N):
                col[i] = (col[i] - mean_good)/std_good
            tX[:,p] = col
        else:
            col = tX[:,p]
            mean_good = np.mean(col)
            std_good = np.std(col)
            for i in range(N):
                col[i] = (col[i] - mean_good)/std_good      
            tX[:,p] = col            

    return tX
